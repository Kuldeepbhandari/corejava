import java.io.*;
class A
{
   public static void main(String str[]) throws Exception
   {
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   String s=br.readLine();
	   System.out.println(s);
	   }
	   }