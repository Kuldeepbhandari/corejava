import java.io.*;
 
 class MyFile {
 String temp = null;

void readFile()
{
        try {
           FileReader is = new FileReader("sample.txt");
                BufferedReader d=new BufferedReader(is);
            while((temp = d.readLine()) != null){

   System.out.println(temp);
            //show(temp);
               Thread.sleep(1000);
            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (Exception e) {
            // TODO Auto-generated catch block
                System.out.println(e);

        }
}
 void show(String s)
{
System.out.println(s);
}


    public static void main(String a[]){

final MyFile f=new MyFile();
Thread t1=new Thread()
{
 public void run()
{
f.readFile();
}
};
Thread t2=new Thread()
{
 public void run()
{
f.show();
}
};
  t1.setDaemon(true);
t1.start();
t2.start();       
}
}