import java.io.*;
class A
{
public static void main(String str[]) throws Exception
{
InputStreamReader dr=new InputStreamReader(System.in);
int s=Integer.valueOf(dr.read());
System.out.println(s);
}
}
   
