class Print 
{
void call(String msg) 
{
System.out.print("[" + msg);
try {
Thread.sleep(1000);
} catch (InterruptedException e) {
System.out.println("Interrupted");
}
System.out.println("]");
}
}

class PrintCaller implements Runnable {
String msg;
Print target;
Thread t;

public PrintCaller(Print targ, String s) {
target = targ;
msg = s;
t = new Thread(this);
t.start();
}

// synchronize calls to call()
public void run() {
synchronized (target) {  // synchronized block
target.call(msg);
}
}
}

 class TreadSynchroniztion {
public static void main(String args[]) {
Print target = new Print();
PrintCaller ob1 = new PrintCaller(target, "Welcome");
PrintCaller ob2 = new PrintCaller(target, "ANR");
PrintCaller ob3 = new PrintCaller(target, "India Office");

System.out.println("Interrupted");
}
}
