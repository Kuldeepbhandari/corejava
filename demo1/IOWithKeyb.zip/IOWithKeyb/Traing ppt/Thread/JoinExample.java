class Print 
{
void call(String msg) 
{
System.out.print("[" + msg);
try 
{
Thread.sleep(1000);
} 
catch (InterruptedException e) 
{
System.out.println("Interrupted");
}
System.out.println("]");
}
}

class PrintCaller implements Runnable 
{
String msg;
Print target;
Thread t;

public PrintCaller(Print targ, String s) 
{
target = targ;
msg = s;
t = new Thread(this);
t.start();
try
{
t.join();
}
catch(Exception xx)
{
}
}

// synchronize calls to call()
public void run() 
{
target.call(msg);

}
}

 class TreadSynTest {
public static void main(String args[]) {
Print target = new Print();
PrintCaller ob1 = new PrintCaller(target, "Welcome in");
PrintCaller ob2 = new PrintCaller(target, "ANR");
PrintCaller ob3 = new PrintCaller(target, "India Office");

}
}