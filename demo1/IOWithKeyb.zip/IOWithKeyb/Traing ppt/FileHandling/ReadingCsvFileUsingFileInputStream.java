import java.io.BufferedInputStream;
 import java.io.FileInputStream;
 import java.util.StringTokenizer;

 class ReadCSVFile {

   public static void main(String[] args) {

     try { 
			
       String csvFile = "SampleCSV.csv";

       //create BufferedReader to read csv file
BufferedInputStream buf=new BufferedInputStream( new FileInputStream(csvFile));
      
      String line="";
       
 StringBuffer sb=new StringBuffer();
       int lineNumber = 0; 

       //read comma separated file line by line
       while ((lineNumber = buf.read()) != -1) 
{
         sb.append((char)lineNumber);
}

for(int i=0;i<sb.length();i++)
{

           System.out.print(sb.charAt(i));
         }


     } catch (Exception e) {
       System.err.println("CSV file cannot be read : " + e);
     }
   }

 }


