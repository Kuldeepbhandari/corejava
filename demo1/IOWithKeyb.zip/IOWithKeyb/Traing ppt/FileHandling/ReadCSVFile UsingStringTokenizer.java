import java.io.BufferedReader;
 import java.io.FileReader;
 import java.util.StringTokenizer;

 class ReadCSVFile {

   public static void main(String[] args) {

     try { 
			
       String csvFile = "SampleCSV.csv";

       //create BufferedReader to read csv file
       BufferedReader br = new BufferedReader(new FileReader(csvFile));
       String line = "";

       int lineNumber = 0; 

       //read comma separated file line by line
       while ((line = br.readLine()) != null) {
         lineNumber++;

         //use comma as token separator
         String st[] =line.split(",");

         
           //display csv values
           System.out.println(st[0]+"  "+st[1]+"  "+st[2]);
         }



     } catch (Exception e) {
       System.err.println("CSV file cannot be read : " + e);
     }
   }

 }


