import java.io.File;

 class Exercise {
    public static void main(String[] args)  throws Exception {
	
// Indicate that you are planning to use a file
	
File fleExample = new File("Example.txt");


if (fleExample.createNewFile()) {
System.out.println("File is created!");

} 
else {
System.out.println("File already exists.");
Student student=FileOperation.registerFile(fleExample);

System.out.println("\nStudent Informaion\n "+student);

      }  //Create that file and prepare to write some values toit
       
    }
}