/* this class will store information about student */

class Student
{
public int id;
public String FirstName;
public String LastName;
public double GPA; 

   Student(int id,String FirstName,String LastName,double GPA )
{
      this.id=id;
      this.FirstName=FirstName;
      this.LastName=LastName;
      this.GPA=GPA;
}


public String toString()
{
  return "First Name is :"+FirstName+ " \n LastName :"+  LastName+ "\n Grade point average: "+GPA;
}
}//Class Close

