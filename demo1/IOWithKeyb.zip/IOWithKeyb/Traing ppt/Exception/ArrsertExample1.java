import java.util.*;
class A
{
 public static void main(String str[])
{
int a;

Scanner sc=new Scanner(System.in);
a=sc.nextInt();
assert (a<5);
System.out.println(" hello my friends.....");
}
}