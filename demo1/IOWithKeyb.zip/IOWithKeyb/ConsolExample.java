import java.io.Console;
import java.util.Arrays;
import java.io.IOException;

 class Password {
    

public static  boolean isValidPassword(char pass[])
{
char passdb[]={'s','a','n','d','e','e','p'};
boolean check=true;
for(int i=0;i<pass.length;i++)
{
if(passdb[i]!=pass[i])
{
check=false;
}
}

return check;

}
    public static void main (String args[]) throws IOException {

        Console c = System.console();
        if (c == null) {
            System.err.println("No console....................");
            System.exit(1);
        }
        System.out.println("Enter user name");

        String login = c.readLine();
      
        System.out.println("Enter user password...............");
        char [] inputpassword = c.readPassword();
   boolean check=isValidPassword(inputpassword);
      if(check==true)
       System.out.println("password is correct.....");
       else
       System.out.println("password is incorrect.....");

}
}