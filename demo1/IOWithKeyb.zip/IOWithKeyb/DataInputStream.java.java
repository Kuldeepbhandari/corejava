
/*
Read Data and swap the value of varibale
*/
import java.io.DataInputStream;

class Datainpu
{

public static String swap(int a,int b)
{
String hold;
a=a*b;
b=a/b;
a=a/b;

return "a = "+a+" and b = "+b;
}
 
   public static void main(String str[]) throws Exception
   {
       DataInputStream dis=new DataInputStream(System.in);
	   System.out.println("Enter first Number...........");
	   int a=Integer.parseInt(dis.readLine());
	   System.out.println("Enter Second Number..........");
	   int b=Integer.parseInt(dis.readLine());
	     System.out.println("Before swap values are a = "+a+" and  b = "+b);
	     String hold= swap(a,b);
	     System.out.println("After swap values are  "+hold);
}
}