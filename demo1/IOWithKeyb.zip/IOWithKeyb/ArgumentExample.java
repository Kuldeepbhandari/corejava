/*
 In this program we take input in 2D array through command line argument and sort them

*/

class claInput
{
   public static void main(String args[])
   {
   
          int sortArray[][]=new int[3][3];
      
          int index=0;
// input procedure
 
         for(int row=0;row<3;row++)
          {
            for(int col=0;col<3;col++)
             {
              sortArray[row][col]=Integer.parseInt(args[index]);
                index++;
                }
           }


//sorting procedure 

         for(int row=0;row<3;row++)
          {
            for(int col=0;col<3;col++)
             {
               for(int r=0;r<3;r++ )
                {
                 for(int c=0;c<3;c++)
                 {
                   if(sortArray[row][col]>=sortArray[r][c])
                    {
                      int temp;
                         temp=sortArray[row][col];
                         sortArray[row][col]=sortArray[r][c];
                         sortArray[r][c]=temp;
                         }
                   }
                  }
                 }
                }
//display elements..

 for(int row=0;row<3;row++)
          {
            for(int col=0;col<3;col++)
             {
                 System.out.print(sortArray[row][col]+" ");
}
System.out.println();
}
}// main end

}// class end