class BankAccount {

    int accountNumber; 
	
    double accountBalance;


    // to withdraw funds from the account
    public synchronized void transfer (double amount) throws Exception  
    {
        double newAccountBalance;

        if( amount > accountBalance)
	{
             //there are not enough funds in the account
             wait();
			 Thread.sleep(2000);
			 System.out.println("mony is trnsfring........");
	}
		
	else
	{
            newAccountBalance = accountBalance - amount;
            accountBalance = newAccountBalance;
			System.out.println(accountBalance);
              }

    }

    public synchronized void deposit(double amount) throws Exception
    {
	double newAccountBalance;

	if( amount < 0.0)
	{
           // can not deposit a negative amount
		   wait();
		   Thread.sleep(2000);
	}
		
	else
	{
          newAccountBalance = accountBalance + amount;
          accountBalance = newAccountBalance;
		  System.out.println(accountBalance);

	  
         }

     }
	 }

	 class test
	 {
	    public static void main(String str[]) throws Exception
		{
		  final BankAccount ac=new BankAccount();
		 Thread thread_1 =new Thread()
		 {
		 public void run() 
		 {
		 try
		 {
		 
		   ac.transfer(4000);
		 }
		 catch(Exception xx)
		 {
		 
		 }
		 }
		 };
		 Thread thread_2 =new Thread() 
		 {
		 public void run()
		 {
		 try
		 {
		   ac.deposit(2000);
		 }
		 catch(Exception xx)
		 {
		 }
		 }
		 };
		 thread_1.start();
		 thread_2.start();
		 thread_1.notify();
		 thread_2.notify();
		}
		}
		