﻿//Use thread by extending Thread class
class ThreadExample extends Thread
{

public void run()
{
System.out.println("threaad class Example")
}
      public static void main(String str[])
	  {
	      Thread t=new Thread();
		  t.start(); //now run method invoked
		  }
		  }