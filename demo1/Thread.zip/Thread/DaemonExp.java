class th1  extends Thread
{
   public void run()
{
try
{
 for(int i=0;i<10;i++)
{
     System.out.println(i);
   sleep(2000);
}
}
catch(Exception xx)
{
   }
}
}
class th2  extends Thread
{
   public void run()
{
try
{
 for(int i=0;i<5;i++)
{
     System.out.println(i);
   sleep(2000);
}
}
catch(Exception xx)
{
   }
}
   }

class Test
{
   public static void main(String str[])
{
     th1 thread1=new th1();
     th2 thread2=new th2();
  thread1.setDaemon(true);
   thread1.start();
  thread2.start();
}
}    