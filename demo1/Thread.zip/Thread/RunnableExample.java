
  class MyRunnable implements Runnable {
  private final long countUntil;

  MyRunnable(long countUntil) {
    this.countUntil = countUntil;
  }

  //Override
  public void run() {
    long sum = 0;
    for (long i = 1; i < countUntil; i++) {
      sum += i;
    }
    System.out.println(sum);
  }
} 


  class Main {

  public static void main(String[] args) {
        // We will create 500 threads
    for (int i = 0; i < 500; i++) {
      Runnable task = new MyRunnable(10000000L + i);
            // We can set the target of the thread
			Thread worker = new Thread(task);

            // Start the thread, never call method run() direct
      worker.start();
      // Remember the thread for later usage
        }
    }
} 